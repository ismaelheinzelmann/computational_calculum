questao1(-60.06)
questao2_1()
questao2_2()
questao2_3()